package cs233;

import java.util.Random;
public class Player {

	private String name;
	private int number;
	private int blockAccuracy;
	private int passAccuracy;
	private int shootAccuracy;
	
	Random accuracy = new Random();
	
	Player( String name, int number){
		this.setName(name);
		this.setNumber(number);
		this.setBlockAccuracy(getBlockAccuracy());
		this.setPassAccuracy(getPassAccuracy());
		this.setShootAccuracy(getShootAccuracy());
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public int getBlockAccuracy() {
		int num = accuracy.nextInt(100);
		return num;
	}

	public void setBlockAccuracy(int blockAccuracy) {
		this.blockAccuracy = blockAccuracy;
	}

	public int getPassAccuracy() {
		int num = accuracy.nextInt(100);
		return num;
	}

	public void setPassAccuracy(int passAccuracy) {
		this.passAccuracy = passAccuracy;
	}

	public int getShootAccuracy() {
		int num = accuracy.nextInt(100);
		return num;
	}

	public void setShootAccuracy(int shootAccuracy) {
		this.shootAccuracy = shootAccuracy;
	}
	
public boolean shoot(int blockAccuracy) {
	boolean success = true;
	if (this.shootAccuracy > blockAccuracy) {
		success = true;
	}
	else if ( this.shootAccuracy < blockAccuracy) {
		success= false;
	}
return success;
}
public boolean pass(int blockAccuracy) {
	boolean success = true;
	if (this.passAccuracy > blockAccuracy) {
		success = true;
	}
	else if ( this.passAccuracy < blockAccuracy) {
		success= false;
	}
return success;
}
public boolean block() {
	int block = (int) (Math.random()* 100)+ 1;
	boolean success = true;
	if ( 50 >= block) {
		success = true;
	}
	else if ( 51 <= block) {
		success = false;
	}
return success;
}
}