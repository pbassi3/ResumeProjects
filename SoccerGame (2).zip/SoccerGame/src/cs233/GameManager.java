package cs233;

//Name: Gurpuneet Bassi  
//Section A
//Program Name: Soccer game
//
//Description: 
//In this assignment, we used all the learning in class to help us efficiently �play� a soccer game 
//I used many loops in my interpretation of this project, this includes for loops, do-while loops, in fact I even used a switch statement to help my coding. //
//First, the program asks for two team names form the user, then displays what happens during the game, this includes passing, shooting, and blocking, and also displays when a team scores a goal. 
//When a team scores three goals, the game ends and the program asks if you want to run it again. 
//If there is not a good condition ball or field, then the program also displays that at the beginning of it.


import java.util.Scanner;
public class GameManager {

	
	


		public static void main(String[] args) {

		Player[] player =  new Player[22];
		player[0]= new Goalie( " Casillas", 1);
		player[1]= new Defense( " Sergio Ramos", 4);
		player[2]= new Defense ( " Pique", 3);
		player[3]= new Defense(" Pepe", 14);
		player[4]= new Defense (" Jordi Alba", 12);
		player[5]= new MidField(" Xavi", 6);
		player[6]= new MidField(" Iniesta", 8);
		player[7]=  new MidField(" Neymar", 11);
		player[8]= new Forward( " Messi", 10);
		player[9]= new Forward( " Ronaldo", 7);
		player[10]= new Forward( " Suarez", 9);

		player[11]= new Goalie( " Neaur", 78);
		player[12]= new Defense( " Boateng", 79);
		player[13]= new Defense ( " Lahm", 80);
		player[14]= new Defense(" Hummels", 81);
		player[15]= new Defense (" Alaba", 82);
		player[16]= new MidField(" Javi Martinez", 83);
		player[17]= new MidField(" Gotze", 84);
		player[18]= new MidField(" Reus", 85);
		player[19]= new Forward( " Mueller", 86);
		player[20]= new Forward( " Gomez", 87);
		player[21]= new Forward( " Lewandowski", 88);

		int Possession;
		int score1 = 0;
		int score2 = 0;
		int choice;
		int block;
		int currentPlayer;
		int startingTeam;
		int passes1 = 0;
		int passes2 = 0;
		int shots1 = 0;
		int shots2 = 0;
		int blocks1 = 0;
		int blocks2 = 0;
		int fieldCondition = 0;
		int ballCondition = 0;
		String answer = "";
		String teamName1;
		String teamName2;
		Scanner input = new Scanner(System.in);

		System.out.println(" ----------------- Welcome to Simple Soccer System-------------------");

		do {
		fieldCondition = (int)(Math.random() * 11);
		ballCondition= (int)(Math.random() * 11);

		if (fieldCondition >=4) {
		if (ballCondition >= 3) {
		System.out.println(" Please enter the name for the first team ! ");
		teamName1 = input.nextLine();
		System.out.println(" Please enter the name for the second team ! ");
		teamName2 = input.nextLine();

		choice = (int)( Math.random()*2) + 1;
		Possession = (int) ( Math.random()* 11);
		startingTeam = (int)(Math.random()*2) + 1;

		do {
		if ( Possession == 0 || Possession ==11) {
		choice = 1;
		}else {
		choice = (int)(Math.random()* 3 ) + 1;
		}




		switch (choice) {
		case 1://Passing the ball
		if ( Possession < 11) {
		block = (int) ((Math.random()* 11) + 11);
		passes1++;
		if( player [Possession].pass(player [block].getBlockAccuracy())){
		currentPlayer = Possession;

		System.out.println(" Team " + teamName1 + " has the ball: "
		+ player[Possession].getNumber() + player[Possession].getName() +
		" is trying to pass the ball, and the pass was successfully completed");
		do {
		Possession = (int) (Math.random() * 11);
		}while( currentPlayer == Possession);
		} else {
		System.out.println(" Team " + teamName1 + " has the ball: " +
		player[Possession].getNumber() + player[Possession].getName() +
		" is trying to pass the ball, but the pass was blocked ");
		blocks2++;
		Possession = block;

		}
		}
		else if ( Possession >= 11) {
		block = (int)(Math.random() * 11);
		passes2++;

		if ( player[Possession].pass(player [block].getBlockAccuracy())){
		currentPlayer = Possession;

		System.out.println(" Team " + teamName2 + " has the ball: " + player[Possession].getNumber() + player[Possession].getName() +
		" is trying to pass the ball, and the pass was successfully completed! ");

		do {
		Possession = (int)((Math.random()* 11)+ 11);
		}while( currentPlayer == Possession);

		}else {
		System.out.println(" Team " + teamName2 + " has the ball: " +
		player[Possession].getNumber() + player[Possession].getName() +
		" is trying to pass the ball, but the pass was blocked ");
		blocks1++;
		Possession = block;
		}
		}
		break;

		case 2: //Shooting the ball
		if ( Possession < 11) {
		block = (int) ((Math.random()* 11) + 11);
		shots1++;
		if( player [Possession].shoot(player [11].getBlockAccuracy())){

		System.out.println(" Team " + teamName1 + " has the ball: "
		+ player[Possession].getNumber() + player[Possession].getName() +
		" is trying to shoot the ball , and the shot has went into the net: GOOOAAALLLL!!!!");
		score1++;
		Possession = (int) ((Math.random()* 10) + 12);

		}else {
		System.out.println(" Team " + teamName1 + " has the ball: "
		+ player[Possession].getNumber() + player[Possession].getName() +
		" is trying to shoot , and the shot was blocked by the goalie! No Goal!");
		blocks2++;
		Possession = 11;
		}
		}
		else if ( Possession >= 12) {
		block = (int)(Math.random()* 11);
		shots2++;
		if( player [Possession].shoot(player [0].getBlockAccuracy())){

		System.out.println(" Team " + teamName2 + " has the ball: "
		+ player[Possession].getNumber() + player[Possession].getName() +
		" is trying to shoot the ball , and the shot has went into the net: GOOOAAALLLL!!!");
		score2++;
		Possession = (int) ((Math.random() * 10 )+ 1);
		}else {
		System.out.println(" Team " + teamName2 + " has the ball: "
		+ player[Possession].getNumber() + player[Possession].getName() +
		" is trying to shoot , and the shot was blocked by the goalie! No Goal!");
		blocks1++;
		Possession = 0;
		}
		}
		break;
		case 3: //Blocking the ball
		if ( Possession < 11) {
		block = (int) ((Math.random() * 11 )+ 11);
		blocks2++;
		if ( player[block].block()) {
		System.out.println(" Team " + teamName1 + " has the ball: "
		+ player[block].getNumber() + player[block].getName() +
		" is trying to block , and the ball was blocked!");

		Possession = block;
		}else {
		System.out.println(" Team " + teamName1 + " has the ball: "
		+ player[block].getNumber() + player[block].getName() +
		" is trying to block , and the ball was not blocked! ");
		if(block==11) {
		score1++;
		Possession = (int)((Math.random()* 10) + 12);
		}
		}
		}else if (Possession >= 11) {
		block = (int) (Math.random()* 11);
		blocks1++;
		if ( player[block].block()) {
		System.out.println(" Team " + teamName2 + " has the ball: "
		+ player[block].getNumber() + player[block].getName() +
		" is trying to block , and the ball was blocked!");

		Possession = block;
		}else {
		System.out.println(" Team " + teamName2 + " has the ball: "
		+ player[block].getNumber() + player[block].getName() +
		" is trying to block , and the ball was not blocked!");
		score2++;
		Possession = (int)((Math.random() * 10) + 12);
		}
		}
		}
		



		}while (score1 < 3 && score2 < 3 );
		if(score1 == 3) {
		System.out.println(" ----------------------------------------------------------- ");
		System.out.println(" Yahoooo! Team " + teamName1 + " has won! "  );
		}else {
		System.out.println(" ----------------------------------------------------------- ");
		System.out.println(" Yahoooo! Team " + teamName2 + " has won! ");
		}
		System.out.println();
		System.out.println(" Team " + teamName1 + "'s match summary ");
		System.out.println(" Goals : " + score1);
		System.out.println(" Shots: " + shots1);
		System.out.println(" Blocks: " + blocks1);
		System.out.println(" Passes Completed: " + passes1);


		System.out.println("--------------------------------------------------------------- ");
		System.out.println(" Team " + teamName2 + "'s match summary ");
		System.out.println(" Goals : " + score2);
		System.out.println(" Shots: " + shots2);
		System.out.println(" Blocks: " + blocks2);
		System.out.println(" Passes Completed: " + passes2);

		score1 = 0;
		passes1 = 0;
		blocks1 = 0;
		shots1 = 0;



		score2 = 0;
		passes2 = 0;
		blocks2 = 0;
		shots2= 0;
		System.out.println(" Do you want to play this fun game again?! (Y:yes, N:no) ");
		answer = input.nextLine();



		System.out.println();
		System.out.println();

		if (answer.equalsIgnoreCase("y")| answer.equalsIgnoreCase("yes")) {
		System.out.println(" ------------ Welcome to the Simple Soccer System -------------");
		}

		}else {
		System.out.println(" Unfortunatley we cannot start the game right now because of this reason: Pitch Grass ");
		System.out.println(" Please come back later, OR do you want me to try again? (Y: yes , N: no ");
		answer = input.nextLine();
		if (answer.equalsIgnoreCase("y")| answer.equalsIgnoreCase("yes")) {
		System.out.println(" Starting a new attempt...... Please Wait ");
		}
		}

		}  


		}while(answer.equalsIgnoreCase("Y")| answer.equalsIgnoreCase("yes"));

		}}
		
