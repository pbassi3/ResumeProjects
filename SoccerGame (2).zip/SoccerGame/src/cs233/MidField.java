package cs233;

public class MidField extends Player {

	MidField(String name, int number) {
		super(name, number);
		
	}
	public int getBlockAccuracy() {
		int num = (int) (Math.random() * 31) + 40;
		return num;
	}
	public int getPassAccuracy() {
		int num = (int) (Math.random() * 31) + 70;
		return num;
	}
	public int getShotAccuracy() {
		int num = (int) (Math.random() * 31) + 40;
		return num;
	}
	public boolean shoot(int blockAccuracy) {
		boolean success = true;
		if (this.getShootAccuracy() > blockAccuracy) {
			success = true;
		}
		else if ( this.getShootAccuracy() < blockAccuracy) {
			success= false;
		}
	return success;
	}
	public boolean pass(int blockAccuracy) {
		boolean success = true;
		if (this.getPassAccuracy() > blockAccuracy) {
			success = true;
		}
		else if ( this.getPassAccuracy() < blockAccuracy) {
			success= false;
		}
	return success;
	}
	public boolean block() {
		int block = (int) (Math.random() * 100 )+ 1;
		boolean success = true;
		if( 40 >= block) {
			success = true;
		}
		else if ( 41 <= block) {
			success = false;
		}
	return success;
	}
	}

