package application;

import java.util.ArrayList;

import java.util.Stack;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;

public class Calc implements EventHandler<ActionEvent> {
	public static Stack<String> myStack = new Stack<String>();
	public static Stack<Double> numbers = new Stack<Double>();
	public static Stack<String> operators = new Stack<String>();
	public static String temp = "";
	
	
	
	@Override
	public void handle(ActionEvent event) {
		Button button = ((Button) event.getSource());

		
		ArrayList<String> operator = new ArrayList<String>();
		operator.add("+");
		operator.add("-");
		operator.add("*");
		operator.add("/");
		operator.add("%");
		operator.add("=");
		
		myStack.push(button.getText());
		
		temp += button.getText();
		Main.text.setText(temp);
		
		if (button.getText().equals ("="))
			Main.text.setText(String.valueOf(calculation()));
		if (button.getText().equals("C")) 
			myStack.empty();
	}
	
	public double calculation() {
		if (myStack.isEmpty())		
			return 0.0;
		
		String number = "";
		for (int i = 0; i < myStack.size(); i++) {
		
			if (myStack.get(i).equals("+") || myStack.get(i).equals("-") || myStack.get(i).equals("*") || myStack.get(i).equals("/") || myStack.get(i).equals("%") || myStack.get(i).equals("=")) {
				operators.push(myStack.get(i));		
				numbers.push(Double.parseDouble(number));
				number = ""; 						
			}
			else {
				number += myStack.get(i);
			}
		}
		
		for (int i = 0; i < numbers.size(); i++) {
			System.out.println (numbers.get(i));
		}
		
		double num1, num2;
		double total = 0;
		String operator;
		
		while (!numbers.isEmpty()) {
			if (numbers.size() < 2)		
				return total;
			
			operator = operators.get(0);
			
			num1 = numbers.get(0);
			num2 = numbers.get(1);		
			switch (operator) {
			case "+":
				total = num1 + num2;
				break;
			case "-":
				total = num1 - num2;
				break;				
			case "*":
				total = num1 * num2;
				break;				
			case "/":
				total = num1 / num2;
				break;				
			case "%":
				total = num1 % num2;
				break;			
			default:
				System.out.println ("ERROR.... PLEASE TRY AGAIN!");
				break;
			}
			numbers.remove(0);
			operators.remove(0);
			numbers.set(0, total);
		}
		return total;
	}
}
