package application;

import java.util.ArrayList;

import java.util.Stack;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;

public class Controls implements EventHandler<ActionEvent> {
	public static Stack<String> myStack = new Stack<String>();
	public static Stack<Double> numbers = new Stack<Double>();
	public static Stack<String> operations = new Stack<String>();
	public static String temp;
	public static String previous;

	@Override
	public void handle(ActionEvent event) {
		Button button = ((Button) event.getSource());
		ArrayList<String> listOfOperators = new ArrayList<String>();
		listOfOperators.add("+");
		listOfOperators.add("-");
		listOfOperators.add("*");
		listOfOperators.add("/");
		listOfOperators.add("%");
		
		myStack.push(button.getText());
		
		temp = "";
		for (int i = 0; i < myStack.size(); i++) {		
			temp += myStack.get(i);
		}
		Main.text.setText(temp);
		
		if (button.getText().equals ("=")) {
			Main.text.setText(String.valueOf(calculation()));
			myStack.remove("=");
		}
		if (button.getText().equals("C")) {
			myStack.clear();
			temp = "";
			Main.text.setText(temp);
		}
		
		if (listOfOperators.contains(previous) && listOfOperators.contains(button.getText())) { 
			myStack.remove(myStack.size() - 2);		
		}											
		if (listOfOperators.contains(button.getText()))
			previous = button.getText();	
		else			
			previous = "";		
	}
	

	public double calculation() {
		if (myStack.isEmpty())		
			return 0.0;
		
		String number = "";
		for (int i = 0; i < myStack.size(); i++) {
			if (myStack.get(i).equals("+") || myStack.get(i).equals("-") || myStack.get(i).equals("*") || myStack.get(i).equals("/") || myStack.get(i).equals("%") || myStack.get(i).equals("=")) {
				operations.push(myStack.get(i));		
				numbers.push(Double.parseDouble(number));
				number = ""; 						
			}
			else {
				number += myStack.get(i);
			}
		}
		
		double number1, number2;
		double totalCalculation = 0;
		String function;
		
		while (!numbers.isEmpty()) {
			if (numbers.size() < 2)	{	
				numbers.set(0, totalCalculation);
				myStack.clear();								
				myStack.push(numbers.get(0).toString());		
				numbers.clear();
				operations.clear();
				return totalCalculation;
			}
			
			function = operations.get(0);
			number1 = numbers.get(0);
			number2 = numbers.get(1);			
			
			switch (function) {
			case "+":
				totalCalculation = number1 + number2;
				break;
			case "-":
				totalCalculation = number1 - number2;
				break;				
			case "*":
				totalCalculation = number1 * number2;
				break;				
			case "/":
				totalCalculation = number1 / number2;
				break;				
			case "%":
				totalCalculation = number1 % number2;
				break;			
			default:
				System.out.println ("ERROR...PLEASE TRY AGAIN!");
				break;
			}
			numbers.remove(0);
			operations.remove(0);
			numbers.set(0, totalCalculation);
		}
		return totalCalculation;
	}
	
	public void clearList() {
		myStack.clear();
	}
}
