package application;
	
import javafx.animation.FadeTransition;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Bounds;
import javafx.geometry.Insets;

public class Main extends Application {
	public static Label text;
	@Override
	public void start(Stage primaryStage) {
		try {
			Pane canvas = new Pane();
			canvas.setPrefSize(500, 500);
			StackPane root = new StackPane();
			primaryStage.setTitle("Puneet's Calculator");
			final Scene scene = new Scene(root, 500, 500);
			root.setBackground(new Background(new BackgroundFill(Color.AQUAMARINE, CornerRadii.EMPTY, Insets.EMPTY)));


			Button button1 = new Button("1");		
			button1.setTranslateX(-200);
			button1.setTranslateY(-100);
			Button button2 = new Button("2");
			button2.setTranslateX(-100);
			button2.setTranslateY(-100);
			Button button3 = new Button("3");
			button3.setTranslateX(0);
			button3.setTranslateY(-100);
			Button button4 = new Button("4");
			button4.setTranslateX(-200);
			button4.setTranslateY(0);
			Button button5 = new Button("5");
			button5.setTranslateX(-100);
			button5.setTranslateY(0);
			Button button6 = new Button("6");
			button6.setTranslateX(0);
			button6.setTranslateY(0);
			Button button7 = new Button("7");
			button7.setTranslateX(-200);
			button7.setTranslateY(100);
			Button button8 = new Button("8");
			button8.setTranslateX(-100);
			button8.setTranslateY(100);
			Button button9 = new Button("9");
			button9.setTranslateX(0);
			button9.setTranslateY(100);
			Button button0 = new Button("0");
			button0.setTranslateX(-200);
			button0.setTranslateY(200);
			
			Button buttonDot = new Button(".");		
			buttonDot.setTranslateX(-100);
			buttonDot.setTranslateY(200);
			Button buttonEquals = new Button("=");
			buttonEquals.setTranslateX(0);
			buttonEquals.setTranslateY(200);
			Button buttonPlus = new Button ("+");
			buttonPlus.setTranslateX(100);
			buttonPlus.setTranslateY(-100);
			Button buttonMinus = new Button ("-");
			buttonMinus.setTranslateX(100);
			buttonMinus.setTranslateY(0);
			Button buttonMult = new Button ("*");
			buttonMult.setTranslateX(100);
			buttonMult.setTranslateY(100);
			Button buttonDiv = new Button ("/");
			buttonDiv.setTranslateX(100);
			buttonDiv.setTranslateY(200);
			Button buttonModulo = new Button ("%");
			buttonModulo.setTranslateX(200);
			buttonModulo.setTranslateY(-100);
			Button buttonClear = new Button ("C");
			buttonClear.setTranslateX(215);
			buttonClear.setTranslateY(0);
			
			button1.setOnAction(new Controls());
			button2.setOnAction(new Controls());
			button3.setOnAction(new Controls());
			button4.setOnAction(new Controls());
			button5.setOnAction(new Controls());
			button6.setOnAction(new Controls());
			button7.setOnAction(new Controls());
			button8.setOnAction(new Controls());
			button9.setOnAction(new Controls());
			button0.setOnAction(new Controls());
			
			buttonPlus.setOnAction(new Controls());
			buttonMinus.setOnAction(new Controls());
			buttonMult.setOnAction(new Controls());
			buttonDiv.setOnAction(new Controls());
			buttonEquals.setOnAction(new Controls());
			buttonModulo.setOnAction(new Controls());
			buttonClear.setOnAction(new Controls());
			buttonDot.setOnAction(new Controls());
			
			text = new Label();
			text.setBackground(new Background(new BackgroundFill(Color.DEEPPINK, CornerRadii.EMPTY, Insets.EMPTY)));	
			text.setFont(Font.font("Times New Roman", 30));
			text.setTranslateX(-20);
			text.setTranslateY(-200);
			
			Rectangle rect = new Rectangle (409, 57);		
			rect.setFill(Color.BEIGE);
			rect.setTranslateX(-20);
			rect.setTranslateY(-200);
			
			FadeTransition ft = new FadeTransition(Duration.millis(3000), root);			
			ft.setFromValue(1.0);
			ft.setToValue(.5);
			ft.setCycleCount(Timeline.INDEFINITE);
			ft.setAutoReverse(true);
			ft.play();
			
			Label name =  new Label("PUNEET");
			name.setBackground(null);
			name.setFont(Font.font("Algerian", 24));
			
			canvas.getChildren().add(name);
			canvas.setBackground(null);
			
			Group group = new Group();
			group.getChildren().addAll(canvas);

			root.getChildren().addAll(group, button1, button2, button3, button4, button5, button6, button7, button8, button9,button0
					,buttonDot, buttonEquals, buttonPlus, buttonMinus, buttonMult, buttonDiv, buttonModulo, buttonClear
					, rect, text);
			
			primaryStage.setScene(scene);
			primaryStage.show();

			final Timeline loop = new Timeline(new KeyFrame(Duration.millis(10), new EventHandler<ActionEvent>() {
			double deltaX = 3;
			double deltaY = 3;
			@Override
			public void handle(final ActionEvent t) {
				name.setLayoutX(name.getLayoutX() + deltaX);
				name.setLayoutY(name.getLayoutY() + deltaY);
			final Bounds bounds = root.getBoundsInLocal();
			final boolean RightBorder = name.getLayoutX() >= (bounds.getMaxX()-name.getWidth());		
			final boolean LeftBorder = name.getLayoutX() <= (bounds.getMinX());
			final boolean BottomBorder = name.getLayoutY() >= (bounds.getMaxY()-name.getHeight());	
			final boolean TopBorder = name.getLayoutY() <= (bounds.getMinY());

			if (RightBorder || LeftBorder) {	
			deltaX *= -1;
			}
			if (BottomBorder || TopBorder) {
			deltaY *= -1;
			}
			}
			}));
			loop.setCycleCount(Timeline.INDEFINITE);
			loop.play();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
